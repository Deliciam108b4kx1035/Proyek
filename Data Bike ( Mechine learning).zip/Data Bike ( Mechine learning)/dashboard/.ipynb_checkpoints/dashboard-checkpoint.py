
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

# Load data
data = pd.read_csv('main_data.csv')

# Title for the dashboard
st.title("Bike Sharing Data Analysis Dashboard")

# Visualization: Weather vs Bike Rentals
st.subheader("Average Bike Rentals by Weather Situation")
weather_vs_rentals = data.groupby('weathersit')['cnt'].mean().reset_index()
weather_labels = {1: 'Clear/Few Clouds', 2: 'Mist/Cloudy', 3: 'Light Snow/Rain', 4: 'Heavy Rain/Snow'}
weather_vs_rentals['weathersit'] = weather_vs_rentals['weathersit'].map(weather_labels)

# Plot weather vs rentals
fig, ax = plt.subplots()
ax.bar(weather_vs_rentals['weathersit'], weather_vs_rentals['cnt'])
ax.set_xlabel("Weather Situation")
ax.set_ylabel("Average Bike Rentals")
st.pyplot(fig)

# Visualization: Working Days vs Bike Rentals
st.subheader("Bike Rentals on Holidays vs Working Days")
fig, ax = plt.subplots()
ax.boxplot([data[data['workingday'] == 0]['cnt'], data[data['workingday'] == 1]['cnt']])
ax.set_xticklabels(['Holiday/Weekend', 'Working Day'])
ax.set_ylabel("Total Bike Rentals")
st.pyplot(fig)
