
# Bike Sharing Data Analysis Project

This project performs data analysis on the bike sharing dataset to derive insights on bike rental trends with respect to weather conditions and working days.

## Structure
- **dashboard**: Contains the dashboard application for Streamlit.
  - `main_data.csv`: The dataset used for visualizations in the dashboard.
  - `dashboard.py`: The Python script for running the Streamlit dashboard.
  
- **data**: Contains the raw data files used in the project.
  - `data_1.csv`, `data_2.csv`: Subsets of the data for analysis.
  
- **notebook.ipynb**: Jupyter Notebook containing the complete data analysis.
- **requirements.txt**: List of dependencies for the project.
- **url.txt**: URL to the deployed Streamlit dashboard.

## Running the Dashboard
1. Install dependencies from `requirements.txt`.
2. Run the dashboard using:
   ```
   streamlit run dashboard/dashboard.py
   ```

## Dataset
The dataset includes bike rental information and weather data. It is analyzed to answer the following business questions:
- How does the weather affect bike rentals?
- Is there a significant difference in bike rentals between working days and holidays?
